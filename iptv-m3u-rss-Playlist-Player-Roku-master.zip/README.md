 # Roku-IPTV
 The Simplest Application for Roku you can use to watch IPTV

 Please, feel free to fork and PR. Now it's just a draft
 
 Thanks @kane2931 for ideas and updates. I had to rewrite many things, but he made good job.
